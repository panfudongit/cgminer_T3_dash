
make distclean

./configure --enable-bitmine_A1 --without-curses --host=arm-linux-gnueabi --build=x86_64-pc-linux-gnu

make
